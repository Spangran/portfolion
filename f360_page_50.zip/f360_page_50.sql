prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.8'
,p_default_workspace_id=>54516756563646975
,p_default_application_id=>244
,p_default_id_offset=>174495260089960987
,p_default_owner=>'PORTFOLION'
);
end;
/
 
prompt APPLICATION 244 - portfoliON  Development (116)
--
-- Application Export:
--   Application:     244
--   Name:            portfoliON  Development (116)
--   Exported By:     PORTFOLION
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 50
--   Manifest End
--   Version:         24.2.8
--   Instance ID:     218248789470801
--

begin
null;
end;
/
prompt --application/pages/delete_00050
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>50);
end;
/
prompt --application/pages/page_00050
begin
wwv_flow_imp_page.create_page(
 p_id=>50
,p_name=>'TODO App'
,p_alias=>'TODO-APP'
,p_step_title=>'TODO App'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'#APP_FILES#portfolion_todo_apex_umd.js',
'#APP_FILES#portfolion_todo_apex_umd#MIN#.js',
''))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Shim the bad pageItems selector used by v1.0 */',
'(function(){',
'  var orig = apex.server.process;',
'  apex.server.process = function(pName, pData, pOpts){',
'    if (pData && typeof pData.pageItems === ''string'') {',
'      // Fix the exact broken pattern from the UMD',
'      if (pData.pageItems === ''#P0_TENANCY_ID,P50_LIST_ID,P50_VL,P50_Q,P50_TASK_ID#'') {',
'        pData = Object.assign({}, pData, {',
'          pageItems: [''P0_TENANCY_ID'',''P50_LIST_ID'',''P50_VL'',''P50_Q'',''P50_TASK_ID'']',
'                      .map(function(x){ return ''#''+x; }).join('','')',
'        });',
'      }',
'    }',
'    return orig.call(apex.server, pName, pData, pOpts);',
'  };',
'})();',
'',
'',
'(function mountWhenReady(){',
'  if (window.PortfolionTodo && window.PortfolionTodo.mount) {',
'    window.PortfolionTodo.mount(''todo-root'', {});',
'  } else {',
'    setTimeout(mountWhenReady, 30);',
'  }',
'})();',
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#TODO {',
'  height: calc(100vh - 180px);',
'  overflow-y: auto;',
'}',
'',
'',
'/* Softer cards like the mock */',
'.t-Card { border-radius: 1rem; }',
'.t-Region { border-radius: 1rem; }',
'',
'.todo-nav-link {',
'  display:flex; align-items:center; gap:.5rem;',
'  padding:.5rem .6rem; border-radius:.6rem;',
'}',
'.todo-nav-link:hover { background:#f3f4f6; }',
'.todo-nav-link .fa { width:1.1rem; text-align:center; opacity:.8; }',
'.todo-nav-link .t-Badge { margin-left:auto; }',
'.todo-nav-link.is-active { background:#eef2ff; font-weight:600; }',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(84100911231414462)
,p_plug_name=>'To-Do'
,p_region_name=>'TODO'
,p_region_template_options=>'#DEFAULT#:margin-top-sm:margin-left-md:margin-right-md'
,p_plug_template=>wwv_flow_imp.id(47661481995296500319)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="todo-root" style="min-height:640px"></div>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(91057927274322729)
,p_plug_name=>'TODO App'
,p_title=>'TODO App'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useRegionTitle'
,p_plug_template=>wwv_flow_imp.id(47661516681249500352)
,p_plug_display_sequence=>200
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_plug_source=>'Project: &P0_PROJECT_NAME.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1938023431744173476)
,p_plug_name=>'Project Navigation menu'
,p_region_name=>'SUB_MENU'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(47661481995296500319)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_05'
,p_location=>null
,p_list_id=>wwv_flow_imp.id(1514254550049631593)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(47661554919002500389)
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(96577192370788363)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(91057927274322729)
,p_button_name=>'Navigation'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight:t-Button--pill'
,p_button_template_id=>wwv_flow_imp.id(47661563564982500401)
,p_button_image_alt=>'Apps'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'js-menuButton'
,p_icon_css_classes=>'fa-chevron-down'
,p_button_cattributes=>' data-menu="SUB_MENU_menu" '
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(84097661062414430)
,p_name=>'P50_LIST_ID'
,p_item_sequence=>150
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(84097741357414431)
,p_name=>'P50_TASK_ID'
,p_item_sequence=>190
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(84100979130414463)
,p_name=>'P50_Q'
,p_item_sequence=>180
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91057101211322721)
,p_name=>'P50_VL'
,p_item_sequence=>160
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(92421682654568855)
,p_name=>'Edit link'
,p_event_sequence=>10
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'PF_EDIT_TASK'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(92421832572568856)
,p_event_id=>wwv_flow_imp.id(92421682654568855)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P50_TASK_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(console.log(''PF_EDIT_TASK payload:'', this.data), this.data?.id)',
''))
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(92421870872568857)
,p_event_id=>wwv_flow_imp.id(92421682654568855)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_MHO.REDIRECT'
,p_attribute_01=>'static'
,p_attribute_02=>'f?p=&APP_ID.:195:&SESSION.::&DEBUG.::P195_ID,P195_REFERENCE_ID,P195_REFERENCE_TYPE:&P50_TASK_ID.,&P50_TASK_ID.,Action'
,p_attribute_04=>'Y'
,p_attribute_05=>'P50_TASK_ID'
,p_attribute_07=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(91058338605322733)
,p_name=>'New'
,p_event_sequence=>20
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(91059113809322741)
,p_event_id=>wwv_flow_imp.id(91058338605322733)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Fire your custom refresh event',
'document.dispatchEvent(new CustomEvent(''PF_TODO_DATA_CHANGED''));',
'if (window.$ && $.fn) { $(document).trigger(''PF_TODO_DATA_CHANGED''); }',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(84097911682414432)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'iNIT DEFAULT LIST'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P50_LIST_ID is null then',
'  select id into :P50_LIST_ID',
'    from v_todo_lists',
'   where tenancy_id = :P0_TENANCY_ID',
'   order by nvl(sort_order,9999), upper(name)',
'   fetch first 1 rows only;',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>258593171772375419
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(91056784948322718)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'TODO_GET_NAV'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  -- Virtual list counters',
'  l_myday        number;',
'  l_important    number;',
'  l_planned      number;',
'  l_assigned     number;',
'  l_open         number;',
'  l_unsorted     number;',
'begin',
'  ---------------------------------------------------------------------------',
'  -- Virtual list counts (TB_WORKITEMS; "DONE" determined by TB_LOV on status)',
'  ---------------------------------------------------------------------------',
'',
'  -- My Day: due today, not done',
'  select count(*) into l_myday',
'    from tb_workitems wi',
'   where wi.tenancy_id = :P0_TENANCY_ID',
'     and wi.work_type  in (''TODO'', ''KANBAN'')',
'     and trunc(wi.due_date) = trunc(sysdate)',
'     and not exists (',
'           select 1 from tb_lov s',
'            where s.id = wi.status_id',
'              and s.tenancy_id = wi.tenancy_id',
'              and upper(nvl(s.display_value, s.value)) = ''DONE''',
'         );',
'',
'  -- Important: high/critical, not done',
'  select count(*) into l_important',
'    from tb_workitems wi',
'   where wi.tenancy_id = :P0_TENANCY_ID',
'     and wi.work_type  in (''TODO'', ''KANBAN'')',
'     and upper(nvl(wi.priority,''LOW'')) in (''HIGH'',''CRITICAL'')',
'     and not exists (',
'           select 1 from tb_lov s',
'            where s.id = wi.status_id',
'              and s.tenancy_id = wi.tenancy_id',
'              and upper(nvl(s.display_value, s.value)) = ''DONE''',
'         );',
'',
'  -- Planned: has due date, not done',
'  select count(*) into l_planned',
'    from tb_workitems wi',
'   where wi.tenancy_id = :P0_TENANCY_ID',
'     and wi.work_type  in (''TODO'', ''KANBAN'')',
'     and wi.due_date is not null',
'     and not exists (',
'           select 1 from tb_lov s',
'            where s.id = wi.status_id',
'              and s.tenancy_id = wi.tenancy_id',
'              and upper(nvl(s.display_value, s.value)) = ''DONE''',
'         );',
'',
'  -- Assigned to me: assignee is current user, not done',
'  select count(*) into l_assigned',
'    from tb_workitems wi',
'   where wi.tenancy_id = :P0_TENANCY_ID',
'     and wi.work_type  in (''TODO'', ''KANBAN'')',
'     and wi.assignee_id = :P0_PERSON_ID',
'     and not exists (',
'           select 1 from tb_lov s',
'            where s.id = wi.status_id',
'              and s.tenancy_id = wi.tenancy_id',
'              and upper(nvl(s.display_value, s.value)) = ''DONE''',
'         );',
'',
'  -- Open: everything not done',
'  select count(*) into l_open',
'    from tb_workitems wi',
'   where wi.tenancy_id = :P0_TENANCY_ID',
'     and wi.work_type  in (''TODO'', ''KANBAN'')',
'     and not exists (',
'           select 1 from tb_lov s',
'            where s.id = wi.status_id',
'              and s.tenancy_id = wi.tenancy_id',
'              and upper(nvl(s.display_value, s.value)) = ''DONE''',
'         );',
'',
'  -- Unsorted: no list_id, created by me',
'  select count(*) into l_unsorted',
'    from tb_workitems wi',
'   where wi.tenancy_id = :P0_TENANCY_ID',
'     and wi.work_type in (''TODO'',''KANBAN'')',
'     and wi.list_id is null',
'     and wi.created_by = nvl(wwv_flow.g_user, user);',
'',
'  ---------------------------------------------------------------------------',
'  -- Emit JSON',
'  ---------------------------------------------------------------------------',
'  apex_json.open_object;',
'  apex_json.open_array(''items'');',
'',
'  -- Virtual lists (kind = VIRTUAL)',
'  apex_json.open_object; apex_json.write(''key'',''MYDAY'');     apex_json.write(''label'',''My Day'');         apex_json.write(''icon'',''calendar''); apex_json.write(''badge'',l_myday);     apex_json.write(''divider'',false); apex_json.write(''kind'',''VIRTUAL''); ape'
||'x_json.close_object;',
'  apex_json.open_object; apex_json.write(''key'',''IMPORTANT''); apex_json.write(''label'',''Important'');      apex_json.write(''icon'',''flag'');     apex_json.write(''badge'',l_important); apex_json.write(''divider'',false); apex_json.write(''kind'',''VIRTUAL''); ape'
||'x_json.close_object;',
'  apex_json.open_object; apex_json.write(''key'',''PLANNED'');   apex_json.write(''label'',''Planned'');        apex_json.write(''icon'',''calendar''); apex_json.write(''badge'',l_planned);   apex_json.write(''divider'',false); apex_json.write(''kind'',''VIRTUAL''); ape'
||'x_json.close_object;',
'  apex_json.open_object; apex_json.write(''key'',''ASSIGNED'');  apex_json.write(''label'',''Assigned to me''); apex_json.write(''icon'',''user'');     apex_json.write(''badge'',l_assigned);  apex_json.write(''divider'',false); apex_json.write(''kind'',''VIRTUAL''); ape'
||'x_json.close_object;',
'  apex_json.open_object; apex_json.write(''key'',''OPEN'');      apex_json.write(''label'',''Open'');           apex_json.write(''icon'',''circle'');   apex_json.write(''badge'',l_open);      apex_json.write(''divider'',false); apex_json.write(''kind'',''VIRTUAL''); ape'
||'x_json.close_object;',
'  apex_json.open_object; apex_json.write(''key'',''UNSORTED'');  apex_json.write(''label'',''Unsorted'');       apex_json.write(''icon'',''inbox'');    apex_json.write(''badge'',l_unsorted);  apex_json.write(''divider'',false); apex_json.write(''kind'',''VIRTUAL''); ape'
||'x_json.close_object;',
'',
'  -- Divider',
'  apex_json.open_object; apex_json.write(''key'',''DIV''); apex_json.write(''divider'',true); apex_json.close_object;',
'',
'  ---------------------------------------------------------------------------',
'  -- Real lists with open-item counts, project info, RBAC can_admin (kind=LIST)',
'  -- Uses V_LIST_EFFECTIVE_PERMS for performance; if you don''t have it, see note below.',
'  ---------------------------------------------------------------------------',
'  for r in (',
'    with counts as (',
'      select wi.list_id, count(*) cnt',
'        from tb_workitems wi',
'        left join tb_lov s',
'          on s.id = wi.status_id',
'         and s.tenancy_id = wi.tenancy_id',
'       where wi.tenancy_id = :P0_TENANCY_ID',
'         and wi.work_type  in (''TODO'', ''KANBAN'')',
'         and upper(nvl(s.display_value, s.value)) <> ''DONE''',
'       group by wi.list_id',
'    )',
'    select',
'      l.id                             as id,',
'      l.name                           as name,',
'      case upper(nvl(l.scope,'''')) when ''PROJECT'' then ''folder''',
'                                   when ''SHARED''  then ''users''',
'                                   else ''user'' end as icon,',
'      nvl(c.cnt,0)                     as badge,',
'      l.project_id                     as project_id,',
'      nvl(p.project_name, ''Standalone lists'') as project_name,',
'      case when exists (',
'             select 1',
'               from v_list_effective_perms v',
'              where v.tenancy_id = :P0_TENANCY_ID',
'                and v.list_id    = l.id',
'                and v.user_id    = :P0_PERSON_ID',
'                and v.permission = ''ADMIN''',
'           ) then 1 else 0 end       as can_admin,',
'      l.is_archived                    as is_archived',
'    from v_todo_lists l',
'    left join counts     c on c.list_id = l.id',
'    left join tb_projects p on p.id = l.project_id',
'    where l.tenancy_id = :P0_TENANCY_ID',
'      and l.is_archived = ''N''  -- adjust if numeric',
'    order by nvl(l.sort_order, 9999), upper(l.name)',
'  ) loop',
'    apex_json.open_object;',
'    apex_json.write(''key'',          r.id);',
'    apex_json.write(''label'',        r.name);',
'    apex_json.write(''icon'',         r.icon);',
'    apex_json.write(''badge'',        r.badge);',
'    apex_json.write(''divider'',      false);',
'    apex_json.write(''kind'',         ''LIST'');',
'    apex_json.write(''project_id'',   r.project_id);',
'    apex_json.write(''project_name'', r.project_name);',
'    apex_json.write(''can_admin'',    r.can_admin = 1);',
'    apex_json.write(''is_archived'',  r.is_archived);',
'    apex_json.close_object;',
'  end loop;',
'',
'  apex_json.close_array;',
'  apex_json.close_object;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>265552045038283705
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(91056867517322719)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'TODO_COMPLETE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_done_id tb_lov.id%type;',
'begin',
'  -- find LOV row for DONE in your WORK_STATUS type',
'  select id into l_done_id',
'    from tb_lov',
'   where tenancy_id = :P0_TENANCY_ID',
'     and upper(type) = ''ACTION_STATUS''',
'     and upper(nvl(display_value, value)) = ''DONE''',
'     and rownum = 1;',
'',
'  update tb_workitems',
'     set status_id = l_done_id',
'   where tenancy_id = :P0_TENANCY_ID',
'     and id         = :P50_TASK_ID;',
'',
'  apex_json.open_object; apex_json.write(''updated'', sql%rowcount); apex_json.close_object;',
'exception',
'  when no_data_found then',
'    apex_json.open_object; apex_json.write(''error'',''DONE status not found in TB_LOV (WORK_STATUS)''); apex_json.close_object;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>265552127607283706
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(91056950050322720)
,p_process_sequence=>30
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'TODO_GET_TASKS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_q varchar2(4000) := trim(:P50_Q);',
'begin',
'  apex_json.open_object;',
'  apex_json.open_array(''rows'');',
'',
'  for t in (',
'    select',
'      wi.id,',
'      wi.name,',
'      dbms_lob.substr(wi.description,4000)          as description,',
'      upper(nvl(s.display_value, s.value))          as status,',
'      upper(nvl(wi.priority,''LOW''))                 as priority,',
'      wi.due_date                                   as due_dt,',
'      wi.assignee_id,',
'      wi.project_id,',
'      (select p.first_name || '' '' || p.surname',
'         from tb_people p',
'        where p.id = wi.assignee_id',
'          and p.tenancy_id = wi.tenancy_id)         as assignee_name,',
'      (select count(*)',
'         from t_comments c',
'        where c.tenancy_id    = wi.tenancy_id',
'          and c.reference_id  = wi.id',
'          and c.reference_type = ''Action'')          as comments',
'    from tb_workitems wi',
'    left join tb_lov s',
'      on s.id = wi.status_id',
'     and s.tenancy_id = wi.tenancy_id',
'    where wi.tenancy_id = :P0_TENANCY_ID',
'      and wi.work_type  in (''TODO'',''KANBAN'')',
'      and (',
'            (:P50_LIST_ID is not null and wi.list_id = :P50_LIST_ID)',
'',
'         or (:P50_VL = ''ASSIGNED''  and wi.assignee_id = :P0_PERSON_ID)',
'         or (:P50_VL = ''MYDAY''     and trunc(wi.due_date) = trunc(sysdate))',
'         or (:P50_VL = ''PLANNED''   and wi.due_date is not null)',
'         or (:P50_VL = ''IMPORTANT'' and upper(nvl(wi.priority,''LOW'')) in (''HIGH'',''CRITICAL''))',
'         or (:P50_VL = ''OPEN''      and upper(nvl(s.display_value, s.value)) <> ''DONE'') -- only here we hide DONE',
'         or (:P50_VL = ''UNSORTED''  and wi.list_id is null and wi.created_by = nvl(wwv_flow.g_user, user))',
'          )',
'      and (',
'            l_q is null',
'         or instr(upper(wi.name),       upper(l_q)) > 0',
'         or instr(upper(wi.description), upper(l_q)) > 0',
'          )',
'    order by nvl(wi.sort_order, 999999), upper(wi.name)',
'  ) loop',
'    apex_json.open_object;',
'    apex_json.write(''id'',        t.id);',
'    apex_json.write(''title'',     t.name);',
'    apex_json.write(''description'', nvl(t.description,''''));',
'    apex_json.write(''priority'',  t.priority);',
'    apex_json.write(''status'',    t.status);',
'    apex_json.write(''due'',',
'      case when t.due_dt is not null',
'           then to_char(t.due_dt,''YYYY-MM-DD"T"HH24:MI:SS'')',
'           else null end);',
'    apex_json.write(''assignee'',  nvl(t.assignee_name,''''));',
'    apex_json.write(''projectId'', t.project_id);',
'    apex_json.write(''comments'',  nvl(t.comments,0));',
'    apex_json.close_object;',
'  end loop;',
'',
'  apex_json.close_array; -- rows',
'  apex_json.close_object;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>265552210140283707
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(91057706656322727)
,p_process_sequence=>40
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'TODO_CREATE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_id    tb_workitems.id%type;',
'  l_name  varchar2(500);',
'  l_list  number; -- may be null',
'  l_sort  number;',
'begin',
'  if apex_application.g_f01.count = 0 then',
'    apex_json.open_object; apex_json.write(''error'',''Missing payload''); apex_json.close_object; return;',
'  end if;',
'',
'  -- IMPORTANT: parse the incoming JSON payload first',
'  apex_json.parse(apex_application.g_f01(1));',
'',
'  -- Now these work:',
'  l_name := apex_json.get_varchar2(''name'');',
'  if apex_json.does_exist(''listId'') then',
'    l_list := apex_json.get_number(''listId'');',
'  else',
'    l_list := null;',
'  end if;',
'',
'  if l_name is null then',
'    apex_json.open_object; apex_json.write(''error'',''Name required''); apex_json.close_object; return;',
'  end if;',
'',
'  select nvl(max(sort_order),0)+1',
'    into l_sort',
'    from tb_workitems',
'   where tenancy_id = :P0_TENANCY_ID',
'     and nvl(list_id,-1) = nvl(l_list,-1);',
'',
'  insert into tb_workitems(',
'    tenancy_id, work_type, name, list_id, assignee_id, sort_order, created_by',
'  ) values (',
'    :P0_TENANCY_ID, ''TODO'', l_name, l_list, :P0_PERSON_ID, l_sort, nvl(wwv_flow.g_user, user)',
'  )',
'  returning id into l_id;',
'',
'  apex_json.open_object; apex_json.write(''id'', l_id); apex_json.close_object;',
'exception',
'  when others then',
'    apex_json.open_object; apex_json.write(''error'', sqlerrm); apex_json.close_object;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>265552966746283714
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(91057785617322728)
,p_process_sequence=>50
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'TODO_CREATE_LIST'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_id        tb_lists.id%type;',
'  l_name      varchar2(200) := apex_application.g_x01;                      -- required',
'  l_project   number        := to_number(nullif(apex_application.g_x02,'''')); -- optional',
'  l_tenancy   number        := to_number(nullif(apex_application.g_x03,'''')); -- REQUIRED',
'  l_owner     number        := to_number(nullif(apex_application.g_x04,'''')); -- optional',
'begin',
'  if l_name is null then',
'    apex_json.open_object; apex_json.write(''error'',''Name required''); apex_json.close_object; return;',
'  end if;',
'  if l_tenancy is null then',
'    apex_json.open_object; apex_json.write(''error'',''Tenancy required''); apex_json.close_object; return;',
'  end if;',
'',
'  insert into tb_lists (',
'    tenancy_id,            -- <- REQUIRED, your table is enforcing this',
'    name,',
'    kind,',
'    scope,',
'    project_id,',
'    owner_id',
'  ) values (',
'    l_tenancy,',
'    l_name,',
'    ''TODO'',',
'    ''PROJECT'',',
'    l_project,',
'    l_owner',
'  )',
'  returning id into l_id;',
'',
'  apex_json.open_object; apex_json.write(''list_id'', l_id); apex_json.close_object;',
'exception',
'  when others then',
'    apex_json.open_object; apex_json.write(''error'', sqlerrm); apex_json.close_object;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>265553045707283715
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(91059358607322744)
,p_process_sequence=>60
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LIST_GET_SHARES'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_list_id   number := to_number(apex_application.g_x01); -- list_id',
'  l_name      tb_lists.name%type;',
'  l_proj_id   tb_lists.project_id%type;',
'  l_arch      tb_lists.is_archived%type;',
'  l_projname  tb_projects.project_name%type;',
'  l_can_admin number;',
'begin',
'  -- Existence + tenancy',
'  select l.name, l.project_id, l.is_archived',
'    into l_name, l_proj_id, l_arch',
'    from tb_lists l',
'   where l.id = l_list_id',
'     and l.tenancy_id = :P0_TENANCY_ID;',
'',
'  select nvl(p.project_name, ''Standalone lists'') into l_projname',
'    from tb_projects p',
'   where p.id = l_proj_id;',
'',
'  -- RBAC: can current user administer this list?',
'  l_can_admin := f_has_permission(',
'                   :P0_TENANCY_ID,',
'                   :P0_PERSON_ID,',
'                   ''list.admin'',',
'                   ''LIST'',',
'                   l_list_id',
'                 );',
'',
'  apex_json.open_object;',
'  apex_json.write(''id'', l_list_id);',
'  apex_json.write(''name'', l_name);',
'  apex_json.write(''project_name'', nvl(l_projname, ''Standalone lists''));',
'  apex_json.write(''is_archived'', nvl(l_arch,''N''));',
'  apex_json.write(''can_admin'', l_can_admin = 1);',
'  apex_json.open_array(''shares''); apex_json.close_array; -- keep empty unless you later add explicit sharing UI',
'  apex_json.close_object;',
'exception',
'  when no_data_found then',
'    apex_json.open_object; apex_json.write(''error'',''List not found''); apex_json.close_object;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>265554618697283731
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(91059507644322745)
,p_process_sequence=>70
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LIST_ADMIN'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_action  varchar2(30)  := apex_application.g_x01; -- ''RENAME''|''ARCHIVE''|''UNARCHIVE''|''DELETE''',
'  l_list_id number        := to_number(apex_application.g_x02);',
'  l_name    varchar2(4000) := apex_application.g_x03; -- new name (for RENAME)',
'  l_ok      number;',
'begin',
'  -- Existence + tenancy',
'  declare n number; begin',
'    select count(*) into n',
'      from tb_lists',
'     where id = l_list_id',
'       and tenancy_id = :P0_TENANCY_ID;',
'    if n = 0 then',
'      raise_application_error(-20001, ''List not found'');',
'    end if;',
'  end;',
'',
'  -- RBAC: require list.admin on this resource',
'  l_ok := f_has_permission(:P0_TENANCY_ID, :P0_PERSON_ID, ''list.admin'', ''LIST'', l_list_id);',
'  if l_ok = 0 then',
'    raise_application_error(-20002, ''Not authorized to administer this list'');',
'  end if;',
'',
'  if l_action = ''RENAME'' then',
'    update tb_lists',
'       set name = l_name',
'     where id = l_list_id',
'       and tenancy_id = :P0_TENANCY_ID;',
'',
'  elsif l_action = ''ARCHIVE'' then',
'    update tb_lists',
'       set is_archived = ''Y''',
'     where id = l_list_id',
'       and tenancy_id = :P0_TENANCY_ID;',
'',
'  elsif l_action = ''UNARCHIVE'' then',
'    update tb_lists',
'       set is_archived = ''N''',
'     where id = l_list_id',
'       and tenancy_id = :P0_TENANCY_ID;',
'',
'  elsif l_action = ''DELETE'' then',
'    -- Choose your cascade policy. Here we delete items in the list, then the list.',
'    delete from tb_workitems where list_id = l_list_id and tenancy_id = :P0_TENANCY_ID;',
'    delete from tb_lists     where id     = l_list_id and tenancy_id = :P0_TENANCY_ID;',
'',
'  else',
'    raise_application_error(-20003, ''Unknown action: ''||l_action);',
'  end if;',
'',
'  apex_json.open_object; apex_json.write(''ok'', true); apex_json.close_object;',
'exception',
'  when others then',
'    apex_json.open_object; apex_json.write(''error'', sqlerrm); apex_json.close_object;',
'    raise;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>265554767734283732
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
